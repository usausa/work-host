﻿export function scrollToPrevious(horizontalScrollElement) {
    horizontalScrollElement.scrollToPrevious();
}

export function scrollToNext(horizontalScrollElement) {
    horizontalScrollElement.scrollToNext();
}

export function scrollInView(horizontalScrollElement, viewIndex) {
    horizontalScrollElement.scrollInView(viewIndex);
}